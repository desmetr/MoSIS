convert train.png -resize x30 train.gif
convert rail.png -resize x40 rail.gif
convert red.png -resize 20x red.gif
convert yellow.png -resize 20x yellow.gif
convert green.png -resize 20x green.gif
convert station.png -resize 200x station.gif
